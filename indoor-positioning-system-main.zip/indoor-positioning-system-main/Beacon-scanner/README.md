# BeaconDetecter
Functional project as an example on how detect and get values from a bluetooth beacon.

The logic is contained in "BeaconServiceNew"

Just run it and push the button

Really simple example
